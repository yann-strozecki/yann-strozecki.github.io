
void read_param_file(float * tab, int size);

int inverse_transform(float * tab, int size);
