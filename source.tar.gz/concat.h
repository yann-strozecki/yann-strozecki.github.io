
Map initializemap();

unsigned long long int generate_trees(int verticesnumber, Avl *avl, Map map, FreeEdge *outline);
unsigned long long int generate_paths(int verticesnumber, Avl *avl, Map map, FreeEdge *outline);
