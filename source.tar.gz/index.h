
void compute_all_indices(Avl avl);
float sparsity_exp(Map *M);
int *automorphism (Map *M);
struct Faces faces (Map *M);
void print_all_indices(char *LongDirName,Avl avl);
float sparsity_poly(Map *M);
