


int algo_shortest_longest(Graphe g,int periode,int taille_message);
int algo_3NT(Graphe g,int periode,int taille_message);


int algo_prime(Graphe g,int periode,int taille_message);

int bruteforceiter(Graphe g, int periode,int taille_paquets);

int search(Graphe g,int message_size, int period);

int linear_3NT(Graphe g,int taille_message);


int linear_prime(Graphe g,int taille_message);



int linear_brute(Graphe g,int taille_message);

int linear_search(Graphe g,int taille_message);