int longest_etoile_2(Graphe g,int taille_paquets,int periode, int Tmax,int mode);
int longest_etoile_periodique(Graphe g,int taille_paquets,int periode, int Tmax,int mode);
//int stochastic(Graphe g, int taille_paquets, int periode, int tmax);
int linear_simons_per(Graphe g,int periode,int taille_message,int nb_rand);
//int linear_stochastic(Graphe g,int periode,int taille_message);