float f_max(float a, float b);
float f_min(float a, float b);

void write_files(float* tab_BE,float * tab_CRAN, float* tab_ANSWERS, float * tab_BE_BBU,int table_size);
void print_gnuplot(char * name);