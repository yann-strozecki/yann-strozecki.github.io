void folding_enumeration(Map map, Avl *avl, FreeEdge *outline);

int computeoutline(Map *map, FreeEdge *outline, Vertex *vert);

void printmap(Map *map);//mettre le type et les fonctions des maps dans un seul fichier map.c
