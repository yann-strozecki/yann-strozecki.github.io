
typedef struct graphe{
	int N; //nombre de sommets
	int ** matrice;//matrice d'adjacence pondérée
}Graphe ;




