
int simons(Graphe g, int taille_paquet, int TMAX,int periode, int mode);
int simons_periodique(Graphe g, int taille_paquet,int TMAX, int periode, int mode);



