#include <sys/time.h>

// Return current time in second-micro/nanosecond
double what_time_is_it ();

// Affiche la valeur courante du chronometre
double chrono();
