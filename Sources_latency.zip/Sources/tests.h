

void affiche_solution(Graphe g, int taille_paquet, int * mi, int * wi);

void affiche_etoile(Graphe g);
void affiche_periode(int *p, int periode);


void affiche_tab(int * tab, int taille);


void affiche_matrice(Graphe g);